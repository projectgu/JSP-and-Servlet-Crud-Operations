package com.edutrack.controller;

import com.edutrack.model.Submission;
import com.edutrack.model.User;
import com.edutrack.util.HibernateUtil;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.hibernate.Session;

import java.io.IOException;
import java.util.List;

@WebServlet("/viewResults")
public class ResultServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession httpSession = request.getSession();
        User student = (User) httpSession.getAttribute("user");

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            List<Submission> submissions = session.createQuery(
                "from Submission where student.id = :sid",
                Submission.class
            ).setParameter("sid", student.getId()).list();

            request.setAttribute("submissions", submissions);
            request.getRequestDispatcher("jsp/results.jsp")
                   .forward(request, response);
        }
    }
}
