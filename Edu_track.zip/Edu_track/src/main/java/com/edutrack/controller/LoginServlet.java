package com.edutrack.controller;

import com.edutrack.dao.UserDAO;
import com.edutrack.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private UserDAO userDAO;

    @Override
    public void init() {
        userDAO = new UserDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = userDAO.getUserByEmail(email);

        if (user != null && user.getPassword().equals(password)) {

            // Create session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("role", user.getRole());

            // Role-based redirection
            switch (user.getRole()) {
                case "ADMIN":
                    response.sendRedirect("admin.jsp");
                    break;
                case "TEACHER":
                    response.sendRedirect("teacher.jsp");
                    break;
                case "STUDENT":
                    response.sendRedirect("student.jsp");
                    break;
                default:
                    response.sendRedirect("login.jsp");
            }

        } else {
            response.sendRedirect("login.jsp?error=true");
        }
    }
}
