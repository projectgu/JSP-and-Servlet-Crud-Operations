package com.edutrack.controller;

import com.edutrack.dao.AssignmentDAO;
import com.edutrack.dao.CourseDAO;
import com.edutrack.model.Assignment;
import com.edutrack.model.Course;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

@WebServlet("/uploadAssignment")
@MultipartConfig
public class AssignmentUploadServlet extends HttpServlet {

    private AssignmentDAO assignmentDAO;
    private CourseDAO courseDAO;

    @Override
    public void init() {
        assignmentDAO = new AssignmentDAO();
        courseDAO = new CourseDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String description = request.getParameter("description");
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        Course course = courseDAO.getCourseById(courseId);

        Part assignmentFile = request.getPart("assignmentFile");
        Part answerKeyFile = request.getPart("answerKeyFile");

        String uploadPath = getServletContext().getRealPath("/uploads/");
        new File(uploadPath).mkdir();

        String assignmentPath = uploadPath + assignmentFile.getSubmittedFileName();
        assignmentFile.write(assignmentPath);

        String answerKeyPath = uploadPath + answerKeyFile.getSubmittedFileName();
        answerKeyFile.write(answerKeyPath);

        Assignment assignment = new Assignment();
        assignment.setTitle(title);
        assignment.setDescription(description);
        assignment.setAssignmentFilePath(assignmentPath);
        assignment.setAnswerKeyFilePath(answerKeyPath);
        assignment.setCourse(course);

        assignmentDAO.saveAssignment(assignment);

        response.sendRedirect("jsp/teacher.jsp?uploaded=true");
    }
}
