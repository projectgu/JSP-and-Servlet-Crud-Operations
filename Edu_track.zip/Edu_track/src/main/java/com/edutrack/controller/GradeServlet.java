package com.edutrack.controller;

import com.edutrack.model.Submission;
import com.edutrack.util.HibernateUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.IOException;

@WebServlet("/gradeSubmission")
public class GradeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int submissionId = Integer.parseInt(request.getParameter("submissionId"));
        double marks = Double.parseDouble(request.getParameter("marks"));
        String feedback = request.getParameter("feedback");
        String plagiarismStatus = request.getParameter("plagiarismStatus");

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            Submission submission = session.get(Submission.class, submissionId);
            submission.setMarks(marks);
            submission.setFeedback(feedback);
            submission.setPlagiarismStatus(plagiarismStatus);

            session.update(submission);
            tx.commit();
        }

        response.sendRedirect("jsp/teacher.jsp?graded=true");
    }
}
