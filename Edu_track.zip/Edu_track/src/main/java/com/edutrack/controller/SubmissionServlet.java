package com.edutrack.controller;

import com.edutrack.model.Assignment;
import com.edutrack.model.Submission;
import com.edutrack.model.User;
import com.edutrack.util.HibernateUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.File;
import java.io.IOException;
import java.util.Date;

@WebServlet("/submitAssignment")
@MultipartConfig
public class SubmissionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int assignmentId = Integer.parseInt(request.getParameter("assignmentId"));
        HttpSession httpSession = request.getSession();
        User student = (User) httpSession.getAttribute("user");

        Part filePart = request.getPart("submissionFile");

        String uploadPath = getServletContext().getRealPath("/uploads/");
        new File(uploadPath).mkdir();

        String filePath = uploadPath + filePart.getSubmittedFileName();
        filePart.write(filePath);

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            Assignment assignment = session.get(Assignment.class, assignmentId);

            Submission submission = new Submission();
            submission.setAssignment(assignment);
            submission.setStudent(student);
            submission.setSubmissionFilePath(filePath);
            submission.setSubmittedOn(new Date());
            submission.setPlagiarismStatus("PENDING");

            session.save(submission);
            tx.commit();
        }

        response.sendRedirect("jsp/student.jsp?submitted=true");
    }
}
