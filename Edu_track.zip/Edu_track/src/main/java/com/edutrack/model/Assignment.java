package com.edutrack.model;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "assignments")
public class Assignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;
    private String description;

    // Teacher uploaded question file
    private String assignmentFilePath;

    // Teacher uploaded answer key
    private String answerKeyFilePath;

    @Temporal(TemporalType.DATE)
    private Date dueDate;

    /* Assignment belongs to ONE course */
    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    /* Student submissions for this assignment */
    @OneToMany(mappedBy = "assignment", cascade = CascadeType.ALL)
    private List<Submission> submissions;

    // ===== Getters and Setters =====

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAssignmentFilePath() {
        return assignmentFilePath;
    }

    public void setAssignmentFilePath(String assignmentFilePath) {
        this.assignmentFilePath = assignmentFilePath;
    }

    public String getAnswerKeyFilePath() {
        return answerKeyFilePath;
    }

    public void setAnswerKeyFilePath(String answerKeyFilePath) {
        this.answerKeyFilePath = answerKeyFilePath;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public List<Submission> getSubmissions() {
        return submissions;
    }

    public void setSubmissions(List<Submission> submissions) {
        this.submissions = submissions;
    }
}
