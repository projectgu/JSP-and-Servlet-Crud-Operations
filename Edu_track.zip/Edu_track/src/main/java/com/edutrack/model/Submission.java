package com.edutrack.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "submissions")
public class Submission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    // Uploaded assignment file by student
    private String submissionFilePath;

    @Temporal(TemporalType.TIMESTAMP)
    private Date submittedOn;

    // Plagiarism result
    private String plagiarismStatus; // CLEAN / POSSIBLE_PLAGIARISM

    // Teacher evaluation
    private double marks;
    private String feedback;

    /* Submission belongs to ONE assignment */
    @ManyToOne
    @JoinColumn(name = "assignment_id")
    private Assignment assignment;

    /* Submission belongs to ONE student */
    @ManyToOne
    @JoinColumn(name = "student_id")
    private User student;
    
    @OneToOne(mappedBy = "submission", cascade = CascadeType.ALL)
    private Grade grade;


    // ===== Getters and Setters =====

    public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSubmissionFilePath() {
        return submissionFilePath;
    }

    public void setSubmissionFilePath(String submissionFilePath) {
        this.submissionFilePath = submissionFilePath;
    }

    public Date getSubmittedOn() {
        return submittedOn;
    }

    public void setSubmittedOn(Date submittedOn) {
        this.submittedOn = submittedOn;
    }

    public String getPlagiarismStatus() {
        return plagiarismStatus;
    }

    public void setPlagiarismStatus(String plagiarismStatus) {
        this.plagiarismStatus = plagiarismStatus;
    }

    public double getMarks() {
        return marks;
    }

    public void setMarks(double marks) {
        this.marks = marks;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public Assignment getAssignment() {
        return assignment;
    }

    public void setAssignment(Assignment assignment) {
        this.assignment = assignment;
    }

    public User getStudent() {
        return student;
    }

    public void setStudent(User student) {
        this.student = student;
    }
}
