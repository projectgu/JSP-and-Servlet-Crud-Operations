package com.edutrack.util;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;

public class PlagiarismChecker {

    public static boolean isPlagiarized(String submissionPath, String answerKeyPath) {

        try {
            String submissionText = Files.readString(Paths.get(submissionPath));
            String answerKeyText = Files.readString(Paths.get(answerKeyPath));

            Set<String> submissionWords = new HashSet<>(Set.of(submissionText.split("\\s+")));
            Set<String> answerWords = new HashSet<>(Set.of(answerKeyText.split("\\s+")));

            submissionWords.retainAll(answerWords);

            return submissionWords.size() > 30; // threshold
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
