package Com.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Com.pojo.Pojo;

public class dao {

	 public static Connection connection() {
		 
		 
		 try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		 } catch (ClassNotFoundException e) {
			System.out.println("Driver class not found!");
		 }
		 
		 
		 Connection conn = null;
		 
		 try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/cruds", "root", "");
		} catch (SQLException e) {
			System.out.println("Connection not found");
		}
		 
		return conn;
		 
	 }
	 
	 public static int DataInsert(Pojo p) {
		 
		 int s = 0;
		 
		 Connection cn = connection();
		 
		 String Insert = "insert into student (uname,ucity,mobile) values (?,?,?)";
		 
		 try {
			PreparedStatement ps = cn.prepareStatement(Insert);
			
			ps.setString(1, p.getUname());
			ps.setString(2, p.getUcity());
			ps.setString(3, p.getMobile());
			 
			s = ps.executeUpdate();
			
			if (s>0) {
				System.out.println("Data Insert Success!");
			}
		} catch (SQLException e) {
			System.out.println("Data not Insert Successfully!");
		}
		 
		return s;	 
		 
	 }
	 public static int DataDelete(int id) {
		 
		 int s = 0;
		 
		 Connection cn = connection();
		 	
		 
		 String Delete = "delete from student where id = ?";
		 
		 try {
			PreparedStatement ps = cn.prepareStatement(Delete);
			
			ps.setInt(1, id);
			 
			s = ps.executeUpdate();
			
			if (s>0) {
				System.out.println("Data Delete Success!");
			}
		} catch (SQLException e) {
			System.out.println("Data not delete Successfully!");
		}
		 
		return s;	 
		 
	 }
	 
	public static int Data_update(Pojo p) {
	 
	 int s = 0;
	 
	 Connection cn = connection();
	 	
	 
	 String Update = "update student set uname=?,ucity=?,mobile=? where id=?";
	 
	 try {
		PreparedStatement ps = cn.prepareStatement(Update);
		
		
		ps.setString(1, p.getUname());
		ps.setString(2, p.getUcity());
		ps.setString(3, p.getMobile());
		ps.setInt(4, p.getId());
		
		 
		s = ps.executeUpdate();
		
		if (s>0) {
			System.out.println("Data update Success!");
		}
	} catch (SQLException e) {
		System.out.println("Data not update Successfully!");
	}
	 
	return s;	 
	 
	}
	public static Pojo Single_fetch(int id) {
	
	Connection cn = connection();
	
	Pojo p = new Pojo();
	
	String Fetch = "select*from student where id=?";
	
	
	try {
		PreparedStatement ps = cn.prepareStatement(Fetch);
		
		ps.setInt(1, id);
		
		ResultSet rs = ps.executeQuery();
		
						
			while(rs.next()){
				p.setId(rs.getInt("id"));
				p.setUname(rs.getString("uname"));
				p.setUcity(rs.getString("ucity"));
				p.setMobile(rs.getString("mobile"));
				
			}
			
			System.out.println("Data fetch Success");
	} catch (SQLException e) {
		System.out.println("Data not Fetch successfully!");
	}
	
	return p;

}
	public static List<Pojo> All_Fetch(){
	
	Connection cn =connection();
	
	List<Pojo> lp = new ArrayList<Pojo>();
		
	String Fetch = "select * from student";
	
		try {
			Statement smt = cn.createStatement();
			ResultSet rs = smt.executeQuery(Fetch);
		
			while (rs.next()) {
				
				Pojo p = new Pojo();
				
				p.setId(rs.getInt("id"));
				p.setUname(rs.getString("uname"));
				p.setUcity(rs.getString("ucity"));
				p.setMobile(rs.getString("mobile"));
				
				lp.add(p);
			}
			System.out.println("Data-Fetch success! ");
		
		} catch (SQLException e) {
			System.out.println("Data-Fetch not success! ");
		}
	return lp;
	
	}
	 
}
