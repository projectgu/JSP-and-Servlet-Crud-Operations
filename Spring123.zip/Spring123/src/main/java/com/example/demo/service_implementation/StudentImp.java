package com.example.demo.service_implementation;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Course;
import com.example.demo.model.Student;
import com.example.demo.service.CourseService;
import com.example.demo.service.Studentservice;

@Service
public class StudentImp {
	
	@Autowired
	public Studentservice studentservice;
	
	@Autowired
	public CourseService courseservice;
	
//	public Student createWithCourse(String sname, Integer courseId) {
//		Course course = courseservice.findById(courseId).orElse(null);
//		
//		Student s = new Student();
//		s.setSname(sname);
//		s.setCourse(course);
//		
//		return studentservice.save(s);
//		
//	

	public Student createWithCourse(String sname, Integer courseId) {
		Course course = courseservice. findById(courseId).orElse(null);
		
		Student s = new  Student();
		
		s.setSname(sname);
		s.setCourse(course);
		
		return studentservice.save(s);
	}
	
	//Data Insert
	public Student Insert(Student student) {
		return studentservice.save(student);
	}

	//Data Update
		public Student Update(Student student) {
			return studentservice.save(student);
		}
		
	//Data Delete
		public void Delete(int id) {
			studentservice.deleteById(id);
		}
		
	//Single record fetch
		public Student SingleId(int id) {
			return studentservice.findById(id).orElse(null);
		}

	//All record Fetch
		public List<Student> All(){
			List<Student> list = new ArrayList<>();
			
			studentservice.findAll().forEach(list :: add);
			
			return list;
			
		}
}
