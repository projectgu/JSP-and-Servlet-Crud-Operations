package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring123Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring123Application.class, args);
	}

}
