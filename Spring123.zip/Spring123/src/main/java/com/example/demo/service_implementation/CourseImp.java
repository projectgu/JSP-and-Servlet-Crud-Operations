package com.example.demo.service_implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Course;
import com.example.demo.service.CourseService;

@Service
public class CourseImp {
	
	@Autowired
	private CourseService courseservice;
	
	public Course Insert(Course course) {
		return courseservice.save(course);
	}
	public Course Update(Course course) {
		return courseservice.save(course);
	}
	public void Delete(int cid) {
		courseservice.deleteById(cid);;
	}
	public Course SingleId(int cid) {
		return courseservice.findById(cid).orElse(null);
	}
	public List<Course> AllId(){
		List<Course> list = new ArrayList<>();
		
		courseservice.findAll().forEach(list :: add);
		
		return list;
	}
	
	
}
