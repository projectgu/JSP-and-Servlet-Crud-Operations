package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "student")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Student {
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id;
		
		@Column
		private String sname;
		
		@Column
		private String study;
		
		@ManyToOne(fetch = FetchType.LAZY)
		@JoinTable(name = "course_id")
		@JsonIgnoreProperties("students")
		private Course course;
				
		public Course getCourse() { return course; }
		public void setCourse(Course course) { this.course = course; }
		
		public Student() {}
		public Student(String sname, String study) {
			this.sname = sname;
			this.study = study;
		}
		
		public int getId() { return id; }
		public void setId(int id) { this.id = id; }
		
		public String getSname() { return sname; }
		public void setSname(String sname) { this.sname = sname; }
		
		public String getStudy() { return study; }
		public void setStudy(String study) { this.study = study; }
}
