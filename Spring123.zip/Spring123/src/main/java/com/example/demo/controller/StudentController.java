package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.model.StudentDTO;
import com.example.demo.service_implementation.StudentImp;

@RestController
@RequestMapping("/student")
@CrossOrigin(origins = "http://localhost:5173")
public class StudentController {
	
	@Autowired
	private StudentImp studentimp;
	
		@PostMapping("/insertwithcourse")
		public Student insertwithcourse(@RequestBody StudentDTO dto) {
			return studentimp.createWithCourse(dto.getSname(), dto.getCourseId());
			
		}
	
	//Data Insert
		@PostMapping("/Insert")
		public Student Insert(@RequestBody Student student) {
			return studentimp.Insert(student);
		}

	//Data Update
		@PutMapping("/Update")
		public Student Update(@RequestBody Student student) {
			return studentimp.Update(student);
		}
		
	//Data Delete
		@DeleteMapping("/Delete/{id}")
		public String Delete(@PathVariable int id) {
			studentimp.Delete(id);
			
			return "Data Deleted!";
		}
		
	//Data Single Fetch
		@GetMapping("/Single/{id}")
		public Student Single(@PathVariable int id) {
			return studentimp.SingleId(id);			
		}
	
	//Data All Fetch
		@GetMapping("/AllFetch")
		public List<Student> All(){
			return studentimp.All();
		}
}
