package com.example.demo.model;

public class StudentDTO {

	private String sname;
	private Integer courseId;
	
	public StudentDTO() {}

	public StudentDTO(String sname, Integer courseId) {
		this.sname = sname;
		this.courseId = courseId;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}
}
