package com.pojo;

public class pojo {

	private int cid;
	private String cname;
	private String ccity;
	private boolean status;
	
	public boolean isstatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCcity() {
		return ccity;
	}
	public void setCcity(String ccity) {
		this.ccity = ccity;
	}
}
