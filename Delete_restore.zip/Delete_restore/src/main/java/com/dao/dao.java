package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pojo.pojo;

public class dao {
	
	public static Connection cn() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found!");
		}
		
		Connection cn = null;
		try {
			cn = DriverManager.getConnection("jdbc:mysql://localhost/restore", "root", "");
		} catch (SQLException e) {
			System.out.println("Connection not found!");
		}
		return cn;
	}
	
	public static int Insert(pojo p) {
		Connection cn = cn();
		
		int status = 0;
		
		String Insert = "insert into example (cname,ccity,stutus) values (?,?,?) " ;
		
		try {
			PreparedStatement ps = cn.prepareStatement(Insert);
			
			ps.setString(1, p.getCname());
			ps.setString(2, p.getCcity());
			ps.setBoolean(3, true);
			
			status = ps.executeUpdate();
			
			if(status>0) {
				System.out.println("Insert!");
			}
			
		} catch (SQLException e) {
			System.out.println("Insert not found!");
		}
		return status;
		
		}
	
	public static List<pojo> Disable() {
		Connection cn = cn();
		
		List<pojo> list = new ArrayList<pojo>();
		
		String Delete = "select * from example where stutus=false";
		
		try {
			PreparedStatement ps = cn.prepareStatement(Delete);
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				
				pojo p = new pojo();
				
				p.setCid(rs.getInt("cid"));
				p.setCname(rs.getString("cname"));
				p.setCcity(rs.getString("ccity"));
				
				list.add(p);
			}
			
		} catch (SQLException e) {
			System.out.println("Delete not found!");
		}
		return list;
		
		}
	public static List<pojo> Enable() {
		Connection cn = cn();
		
		List<pojo> list = new ArrayList<pojo>();
		
		String Delete = "select * from example where stutus=true";
		
		try {
			PreparedStatement ps = cn.prepareStatement(Delete);
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				
				pojo p = new pojo();
				
				p.setCid(rs.getInt("cid"));
				p.setCname(rs.getString("cname"));
				p.setCcity(rs.getString("ccity"));
				
				list.add(p);
			}
			
		} catch (SQLException e) {
			System.out.println("Delete not found!");
		}
		return list;
		
		}
	
	public static boolean delete( int cid) {
		Connection cn = cn();
				
		String update = "update example set stutus = false where  cid =?";
		
		try {
			PreparedStatement ps = cn.prepareStatement(update);
			
			ps.setInt(1, cid);
			
			ps.executeUpdate();
			 
			
		} catch (SQLException e) {
			System.out.println("Delete not found!");
		}
		return false;
		
		}
	

	public static boolean restore( int cid) {
		Connection cn = cn();
				
		String update = "update example set stutus = true where  cid =?";
		
		try {
			PreparedStatement ps = cn.prepareStatement(update);
			
			ps.setInt(1, cid);
			
			ps.executeUpdate();
			 
			
		} catch (SQLException e) {
			System.out.println("Delete not found!");
		}
		return true;
		
		}
	
	public static int Update(pojo p) {
		Connection cn = cn();
		
		int status = 0;
		
		String Update = "update example set cname=?, ccity=?, stutus=? where cid=?";
		
		try {
			PreparedStatement ps = cn.prepareStatement(Update);
			
			ps.setString(1, p.getCname());
			ps.setString(2, p.getCcity());
			ps.setBoolean(3, true);
			ps.setInt(4, p.getCid());
			
			status = ps.executeUpdate();
			
			if(status>0) {
				System.out.println("Update!");
			}
			
		} catch (SQLException e) {
			System.out.println("Update not found!");
		}
		return status;
		
		}
	
	public static Boolean DeleteAll(){
		
		Connection cn = cn();
		
		String Update = "update example set stutus = false where stutus = true";
		
		try {
			PreparedStatement ps = cn.prepareStatement(Update);
			
			int s = ps.executeUpdate();
			
			if(s>0) {
				System.out.println("Delete All found!");
			}
			
		} catch (SQLException e) {
			System.out.println("Delete All not found!");
		}
		return false;
		
	}
	
	public static Boolean RestoreAll(){
		
		Connection cn = cn();
		
		String Update = "update example set stutus = true where stutus = false";
		
		try {
			PreparedStatement ps = cn.prepareStatement(Update);
			
			int s = ps.executeUpdate();
			
			if(s>0) {
				System.out.println("Restore All found!");
			}
			
		} catch (SQLException e) {
			System.out.println("Restore All not found!");
		}
		return true;
		
	}
	
	public static pojo Single(int cid) {
		Connection cn = cn();
		
		int status = 0;
		
		pojo p = new pojo();
		
		String Fetch = "select * from example where cid=? ";
		
		try {
			PreparedStatement ps = cn.prepareStatement(Fetch);
			
			ps.setInt(1, cid);
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				p.setCid(rs.getInt("cid"));
				p.setCname(rs.getString("cname"));
				p.setCcity(rs.getString("ccity"));
				
			}
			
			if(status>0) {
				System.out.println("Fetch!");
			}
			
		} catch (SQLException e) {
			System.out.println("Fetch not found!");
		}
		return p;
		
		}
	
	public static List<pojo> All() {
		Connection cn = cn();
				
		List<pojo> lp = new ArrayList<pojo>();
		
		String Fetch = "select * from example";
		
		try {
			Statement ps = cn.createStatement();			
			ResultSet rs = ps.executeQuery(Fetch);
									
			while (rs.next()) {
				
				 pojo p = new pojo();
				 
				p.setCid(rs.getInt("cid"));
				p.setCname(rs.getString("cname"));
				p.setCcity(rs.getString("ccity"));
				
				lp.add(p);
				
			}
			
				System.out.println("Fetch!");
			
		} catch (SQLException e) {
			System.out.println("Fetch not found!");
		}
		return lp;
		
		}
}
