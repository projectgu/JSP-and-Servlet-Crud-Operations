

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.dao;

@WebServlet("/deleteAll")
public class deleteAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public deleteAll() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		dao.DeleteAll();
		
		response.sendRedirect("view");
	}


}
