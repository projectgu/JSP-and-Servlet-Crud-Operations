

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.dao;
import com.pojo.pojo;

@WebServlet("/insert")
public class insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public insert() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cname = request.getParameter("cname");
		String ccity = request.getParameter("ccity");
		
		pojo p = new pojo();
		
		p.setCname(cname);
		p.setCcity(ccity);
		
		int i = dao.Insert(p);
		
		if(i>0) {
			response.sendRedirect("index.jsp");
		}
		
	}


}
